import React from 'react'

export default function page() {
  return (
    <div>
      pricing page
    </div>
  )
}
