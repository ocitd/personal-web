export default function page() {
  return (
    <div>
      this cv page
    </div>
  )
}