globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/6c04e1bb8dff2bf1.js",
      "static/chunks/turbopack-0c5d85ca17845e39.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/6c04e1bb8dff2bf1.js",
      "static/chunks/turbopack-d76e8ba81d1cb566.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/aaea1e64ef7e0faa.js",
    "static/chunks/483561c245736d52.js",
    "static/chunks/50f9503f16d44625.js",
    "static/chunks/0656f51f27ce398d.js",
    "static/chunks/turbopack-37cddb718aeac718.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];