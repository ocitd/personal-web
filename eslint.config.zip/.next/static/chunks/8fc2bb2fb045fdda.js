__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/6c04e1bb8dff2bf1.js",
  "static/chunks/turbopack-d76e8ba81d1cb566.js"
])
