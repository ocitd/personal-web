__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/6c04e1bb8dff2bf1.js",
  "static/chunks/turbopack-0c5d85ca17845e39.js"
])
