export const categories: string[] = [
  "All",
  "Website Design",
  "App Mobile Design",
  "App Desktop",
  "Branding",
];