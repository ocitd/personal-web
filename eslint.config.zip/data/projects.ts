export interface Project {
  img: string;
  title: string;
  category: string;
}

export const projects: Project[] = [
    { img: "/portfolio1.png", title: "Soon", category: "Website Design" },
    { img: "/portfolio2.png", title: "Soon", category: "App Mobile Design" },
    { img: "/portfolio3.png", title: "Soon", category: "App Desktop" },
    { img: "/portfolio5.png", title: "Soon", category: "Branding" },
    { img: "/portfolio1.png", title: "Soon", category: "Website Design" },
    { img: "/portfolio2.png", title: "Soon", category: "App Mobile Design" },
    { img: "/portfolio3.png", title: "Soon", category: "App Desktop" },
    { img: "/portfolio5.png", title: "Soon", category: "Branding" },
    { img: "/portfolio1.png", title: "Soon", category: "Website Design" },
    { img: "/portfolio2.png", title: "Soon", category: "App Mobile Design" },
    { img: "/portfolio3.png", title: "Soon", category: "App Desktop" },
    { img: "/portfolio5.png", title: "Soon", category: "Branding" },
    { img: "/portfolio1.png", title: "Soon", category: "Website Design" },
    { img: "/portfolio2.png", title: "Soon", category: "App Mobile Design" },
    { img: "/portfolio3.png", title: "Soon", category: "App Desktop" },
    { img: "/portfolio5.png", title: "Soon", category: "Branding" },
];